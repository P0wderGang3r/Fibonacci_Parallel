﻿#include <omp.h>
#include <time.h>
#include <iostream>
#include <future>

unsigned fib_seq(unsigned n)
{
	if (n < 2)
		return n;
	return fib_seq(n - 1) + fib_seq(n - 2);
}

unsigned fib_omp(unsigned n)
{
	if (n < 2)
		return n;
	unsigned r1, r2;
#pragma omp task shared(r1)
	{
		r1 = fib_omp(n - 1);
	}
#pragma omp task shared(r2)
	{
		r2 = fib_omp(n - 2);
	}
#pragma omp taskwait
	return r1 + r2;
}

unsigned fib_async_proc(unsigned n) {
	{
		if (n > 2) return fib_async_proc(n - 1) + fib_async_proc(n - 2);
		
		return n;
	}
}

unsigned fib_async(unsigned n)
{
	std::future<unsigned> res = std::async(std::launch::async, fib_async_proc, n);

	return res.get();
}

unsigned fib_async_lambda(unsigned n)
{
	if (n <= 1)
	{
		return n;
	}

	auto proc = ([n]() -> unsigned
		{
			return fib_async_lambda(n - 1) + fib_async_lambda(n - 2);
		});

	std::future<unsigned> res = std::async(std::launch::async, proc);

	return res.get();
}

int main(int argc, char *argv[]) {
	int n = 40;

	double t0;
	unsigned res = 0;
	
	t0 = omp_get_wtime();
	res = fib_seq(n);
	std::cout << res << " with time " << omp_get_wtime() - t0 << std::endl;
	
	/*
	t0 = omp_get_wtime();
	res = fib_omp(n);
	std::cout << res << " with time " << omp_get_wtime() - t0 << std::endl;
	*/

	t0 = omp_get_wtime();
	res = fib_async(n);
	std::cout << res << " with time " << omp_get_wtime() - t0 << std::endl;

	/*
	t0 = omp_get_wtime();
	res = fib_async_lambda(n);
	std::cout << res << " with time " << omp_get_wtime() - t0 << std::endl;
	*/
}